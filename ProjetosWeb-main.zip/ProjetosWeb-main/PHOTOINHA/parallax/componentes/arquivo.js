$(document).ready(function(){
    var height = $('.footer').height();
    $('.sect-t-footer').css('height', height);
});